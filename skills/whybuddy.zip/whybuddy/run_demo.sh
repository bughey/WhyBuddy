#!/usr/bin/env bash
# ================================================================
#  批量生图一键脚本（演示用）
#  用法：① 把下面 KEY= 那行的占位换成你的真实 key
#        ② 终端运行：bash run_demo.sh
#  ⚠️ 本文件会含明文 key，只留你本机：别提交 git、别发别人、别打进 zip。
# ================================================================

# 👇👇👇 就填这一行：把 <PASTE_YOUR_KEY_HERE> 换成你的 key 👇👇👇
KEY="<PASTE_YOUR_KEY_HERE>"
# 👆👆👆 只改上面这一行就够了 👆👆👆

cd "$(dirname "$0")"
export IMAGE_API_KEY="$KEY"

if [ -z "$IMAGE_API_KEY" ] || [ "$IMAGE_API_KEY" = "<PASTE_YOUR_KEY_HERE>" ]; then
  echo "❌ 还没填 key：用编辑器打开 run_demo.sh，把 KEY= 那行的占位换成你的真实 key。"
  exit 1
fi

echo "✅ key 已就位，开始批量生图（模型 gpt-image-2）..."
python scripts/batch_images.py image_config.json examples/batch_prompts.txt --out previews/batch
